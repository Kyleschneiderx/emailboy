// EmailBoy Background Service Worker

const CONFIG = {
  supabaseUrl: 'https://xgllxidtqbkftsbhiinl.supabase.co',
  supabaseKey: 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InhnbGx4aWR0cWJrZnRzYmhpaW5sIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NjMxNTY2NzEsImV4cCI6MjA3ODczMjY3MX0.gCK3wRjpVF-BFwaLrF_3P4Rb3-lbFPqeu7JxHRQKky4',
  portalUrl: 'https://portal-six-henna.vercel.app'
};

CONFIG.functionsUrl = `${CONFIG.supabaseUrl}/functions/v1`;

// Premium status cache (avoid network requests on every content script check)
let premiumCache = {
  isPremium: false,
  lastChecked: 0,
  checkInProgress: null
};
const PREMIUM_CACHE_TTL = 60000; // Cache for 60 seconds

// Initialize on install
chrome.runtime.onInstalled.addListener(() => {
  console.log('EmailBoy installed');
  chrome.storage.local.set({
    emails: [],
    settings: { autoSync: true },
    premiumStatus: false
  });
});

// Message handler
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  handleMessage(message, sender).then(sendResponse);
  return true; // Keep channel open for async
});

async function handleMessage(message, sender) {
  switch (message.type) {
    case 'NEW_EMAILS':
      return await handleNewEmails(message.emails, message.url, message.timestamp);

    case 'GET_EMAILS':
      const result = await chrome.storage.local.get(['emails']);
      return { emails: result.emails || [] };

    case 'CLEAR_EMAILS':
      await chrome.storage.local.set({ emails: [] });
      chrome.action.setBadgeText({ text: '' });
      return { success: true };

    case 'SESSION_UPDATED':
      // Reset premium cache when session changes
      premiumCache = { isPremium: false, lastChecked: 0, checkInProgress: null };
      // Immediately check new premium status
      checkPremiumStatus(true);
      return { success: true };

    case 'CHECK_PREMIUM':
      // Fast path: return cached value immediately, refresh in background if stale
      const now = Date.now();
      const isStale = now - premiumCache.lastChecked >= PREMIUM_CACHE_TTL;

      // If we have a cached value (even if stale), return it immediately
      // This prevents blocking content scripts on network requests
      if (premiumCache.lastChecked > 0 || premiumCache.isPremium) {
        // Refresh in background if stale (don't await)
        if (isStale) {
          checkPremiumStatus().catch(() => {});
        }
        return { isPremium: premiumCache.isPremium };
      }

      // No cached value at all - need to check (first time only)
      const isPremium = await checkPremiumStatus();
      return { isPremium };

    case 'SYNC_NOW':
      return await syncToSupabase();

    case 'REFRESH_PREMIUM':
      // Force refresh premium status
      const freshStatus = await checkPremiumStatus(true);
      return { isPremium: freshStatus };

    default:
      return { error: 'Unknown message type' };
  }
}

// Check premium status with caching and deduplication
async function checkPremiumStatus(forceRefresh = false) {
  const now = Date.now();

  // Return cached value if still valid
  if (!forceRefresh && now - premiumCache.lastChecked < PREMIUM_CACHE_TTL) {
    return premiumCache.isPremium;
  }

  // If a check is already in progress, wait for it
  if (premiumCache.checkInProgress) {
    try {
      return await premiumCache.checkInProgress;
    } catch {
      return premiumCache.isPremium;
    }
  }

  // Start new check
  premiumCache.checkInProgress = (async () => {
    try {
      const result = await chrome.storage.local.get(['supabaseSession']);
      const session = result.supabaseSession;

      if (!session?.access_token) {
        premiumCache.isPremium = false;
        premiumCache.lastChecked = now;
        await chrome.storage.local.set({ premiumStatus: false });
        return false;
      }

      const response = await fetch(`${CONFIG.functionsUrl}/check-subscription`, {
        headers: {
          'Authorization': `Bearer ${session.access_token}`,
          'Content-Type': 'application/json'
        }
      });

      if (!response.ok) {
        // On error, keep existing cached value but update timestamp
        premiumCache.lastChecked = now;
        return premiumCache.isPremium;
      }

      const data = await response.json();
      const isPremium = data.isPremium === true;

      premiumCache.isPremium = isPremium;
      premiumCache.lastChecked = now;
      await chrome.storage.local.set({ premiumStatus: isPremium });

      return isPremium;
    } catch (error) {
      console.error('Premium check error:', error);
      premiumCache.lastChecked = now;
      return premiumCache.isPremium;
    } finally {
      premiumCache.checkInProgress = null;
    }
  })();

  return premiumCache.checkInProgress;
}

// Handle new emails from content script
async function handleNewEmails(emails, url, timestamp) {
  try {
    // Use cached premium status for speed
    const isPremium = premiumCache.isPremium || (await checkPremiumStatus());
    if (!isPremium) {
      return { success: false, reason: 'premium_required' };
    }

    // Get existing emails
    const result = await chrome.storage.local.get(['emails', 'settings']);
    const existingEmails = result.emails || [];
    const settings = result.settings || {};

    // Create email objects
    const newEmailObjects = emails.map(email => ({
      email: email.toLowerCase().trim(),
      url: url,
      timestamp: timestamp,
      domain: email.split('@')[1],
      lastSeen: timestamp
    }));

    // Merge with existing (avoid duplicates, update lastSeen)
    const emailMap = new Map();

    existingEmails.forEach(item => {
      emailMap.set(item.email, item);
    });

    let addedCount = 0;
    newEmailObjects.forEach(item => {
      const existing = emailMap.get(item.email);
      if (existing) {
        // Update existing email
        if (!existing.urls) existing.urls = [existing.url];
        if (!existing.urls.includes(item.url)) {
          existing.urls.push(item.url);
        }
        existing.lastSeen = item.timestamp;
      } else {
        // Add new email
        addedCount++;
        emailMap.set(item.email, {
          ...item,
          urls: [item.url]
        });
      }
    });

    const updatedEmails = Array.from(emailMap.values());

    // Save to local storage
    await chrome.storage.local.set({ emails: updatedEmails });

    // Update badge
    updateBadge(updatedEmails.length);

    // Auto-sync if enabled (in background, don't wait)
    if (settings.autoSync !== false && addedCount > 0) {
      syncToSupabase().catch(err => console.error('Auto-sync error:', err));
    }

    return { success: true, count: updatedEmails.length, added: addedCount };
  } catch (error) {
    console.error('Handle new emails error:', error);
    return { success: false, error: error.message };
  }
}

// Sync to Supabase
async function syncToSupabase() {
  try {
    const result = await chrome.storage.local.get(['emails', 'supabaseSession']);
    const emails = result.emails || [];
    const session = result.supabaseSession;

    if (!session?.access_token) {
      return { success: false, reason: 'not_authenticated' };
    }

    if (emails.length === 0) {
      return { success: true, count: 0 };
    }

    const response = await fetch(`${CONFIG.functionsUrl}/store-emails`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${session.access_token}`
      },
      body: JSON.stringify({ emails })
    });

    if (!response.ok) {
      const error = await response.json().catch(() => ({ error: response.statusText }));
      throw new Error(error.error || 'Sync failed');
    }

    const data = await response.json();

    if (data.success) {
      console.log(`Synced ${data.count} emails to Supabase`);
      await chrome.storage.local.remove(['lastSyncError']);
      showSyncSuccess();
      return { success: true, count: data.count };
    } else {
      throw new Error(data.error || 'Sync failed');
    }
  } catch (error) {
    console.error('Sync error:', error);
    await chrome.storage.local.set({ lastSyncError: error.message });
    showSyncError();
    return { success: false, error: error.message };
  }
}

// Badge helpers
function updateBadge(count) {
  chrome.action.setBadgeText({ text: count > 0 ? count.toString() : '' });
  chrome.action.setBadgeBackgroundColor({ color: '#4AE3A7' });
}

function showSyncSuccess() {
  chrome.action.setBadgeText({ text: '✓' });
  chrome.action.setBadgeBackgroundColor({ color: '#4AE3A7' });

  setTimeout(async () => {
    const result = await chrome.storage.local.get(['emails']);
    const count = (result.emails || []).length;
    updateBadge(count);
  }, 2000);
}

function showSyncError() {
  chrome.action.setBadgeText({ text: '!' });
  chrome.action.setBadgeBackgroundColor({ color: '#FF6B4A' });
}

// Handle checkout success redirect
chrome.webNavigation?.onCommitted?.addListener(async (details) => {
  const url = details.url;

  // Check for checkout success redirect to portal
  if (url.includes(CONFIG.portalUrl) && url.includes('checkout=success')) {
    console.log('Checkout success detected');
    // Force refresh premium status
    setTimeout(async () => {
      const isPremium = await checkPremiumStatus(true);
      console.log('Premium status after checkout:', isPremium);
    }, 2000);
  }
});

// Initialize premium cache from storage on startup
chrome.storage.local.get(['premiumStatus']).then(result => {
  if (result.premiumStatus !== undefined) {
    premiumCache.isPremium = result.premiumStatus;
    // Set lastChecked to now so we trust the cached value initially
    // It will be refreshed in background on first CHECK_PREMIUM call
    premiumCache.lastChecked = Date.now() - PREMIUM_CACHE_TTL + 5000; // Will refresh after 5 seconds
  }
  // Refresh premium status in background after startup
  setTimeout(() => checkPremiumStatus(true).catch(() => {}), 2000);
});

// Periodically refresh premium status in background (every 5 minutes)
setInterval(() => {
  checkPremiumStatus(true).catch(() => {});
}, 300000);
